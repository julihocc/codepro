class Libro:
    def __init__(self, titulo, autor, anio_publicacion, cantidad_copias):
        self.titulo = titulo
        self.autor = autor
        self.anio_publicacion = anio_publicacion
        self.cantidad_copias = cantidad_copias

    def __str__(self):
        return f"{self.titulo} ({self.anio_publicacion}) por {self.autor}. Copias disponibles: {self.cantidad_copias}"


class Biblioteca:
    def __init__(self):
        self.libros = []
        self.prestamos = {}

    def agregar_libro(self, libro):
        self.libros.append(libro)
        print(f"El libro '{libro.titulo}' ha sido agregado exitosamente.")

    def buscar_libro(self, titulo):
        for libro in self.libros:
            if libro.titulo == titulo:
                return libro
        return None

    def prestar_libro(self, usuario, titulo):
        libro = self.buscar_libro(titulo)
        if libro is None:
            print(f"El libro '{titulo}' no se encuentra en la biblioteca.")
            return

        if libro.cantidad_copias == 0:
            print(f"Lo sentimos, no hay copias disponibles del libro '{titulo}'.")
            return

        libro.cantidad_copias -= 1
        self.prestamos[(usuario, titulo)] = "prestado"
        print(f"El préstamo del libro '{titulo}' a {usuario} se ha realizado exitosamente.")

    def devolver_libro(self, usuario, titulo):
        if (usuario, titulo) not in self.prestamos:
            print(f"No se encuentra registrado un préstamo del libro '{titulo}' a {usuario}.")
            return

        libro = self.buscar_libro(titulo)
        libro.cantidad_copias += 1
        del self.prestamos[(usuario, titulo)]
        print(f"La devolución del libro '{titulo}' por {usuario} se ha registrado exitosamente.")


def main():
    biblioteca = Biblioteca()

    # Caso de prueba 1: Agregar un nuevo libro
    orgullo_y_prejuicio = Libro("Orgullo y Prejuicio", "Jane Austen", 1813, 3)
    biblioteca.agregar_libro(orgullo_y_prejuicio)

    # Caso de prueba 2: Buscar un libro existente
    libro = biblioteca.buscar_libro("Orgullo y Prejuicio")
    if libro is not None:
        print("Libro encontrado:", libro)

    # Caso de prueba 3: Buscar un libro inexistente
    libro = biblioteca.buscar_libro("Libro inexistente")
    if libro is None:
        print("El libro 'Libro inexistente' no se encuentra en la biblioteca.")

    # Caso de prueba 4: Realizar un préstamo
    biblioteca.prestar_libro("Juan Pérez", "Orgullo y Prejuicio")

    # Caso de prueba 5: Devolver un libro
    biblioteca.devolver_libro("Juan Pérez", "Orgullo y Prejuicio")

    # Caso de prueba 6: Realizar un préstamo sin copias disponibles
    libro_sin_copias = Libro("Libro sin copias", "Autor desconocido", 2000, 0)
    biblioteca.agregar_libro(libro_sin_copias)
    biblioteca.prestar_libro("Ana Sánchez", "Libro sin copias")

    # Caso de prueba 7: Devolver un libro no prestado
    libro_no_prestado = Libro("Libro no prestado", "Otro autor", 1999, 2)
    biblioteca.agregar_libro(libro_no_prestado)
    biblioteca.devolver_libro("Carlos López", "Libro no prestado")


if __name__ == "__main__":
    main()
